package com.example.berthaperssensorapp;

import android.os.AsyncTask;
import android.util.Log;

import java.io.IOException;


public class httpRead extends AsyncTask<String,Void,CharSequence> {
    @Override
    protected CharSequence doInBackground(String... urls){
        String urlString = urls[0];
        try {
            CharSequence result=httphelper.GetHttpResponse(urlString);
            return result;
        }catch (IOException ex){
            cancel(true);
            String errorMessage = ex.getMessage() + "\n" + urlString;
            Log.e("DATA", errorMessage);
            return errorMessage;
        }
    }

}
