package com.example.berthaperssensorapp

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View

import android.widget.CheckBox
import android.widget.EditText


class MainActivity : AppCompatActivity() {
    private var preferences: SharedPreferences? = null
    private var usernameField: EditText? = null
    private var passwordField: EditText? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        preferences = getSharedPreferences(PREF_FILE_NAME, Context.MODE_PRIVATE)
        usernameField = findViewById(R.id.aName)
        passwordField = findViewById(R.id.aPassword)
        val username = preferences!!.getString(USERNAME, null)
        val password = preferences!!.getString(PASSWORD, null)
        if (username != null && password != null) {
            usernameField!!.setText(username)
            passwordField!!.setText(password)
        }


    }

    fun validate(view: View) {
        val username = usernameField!!.text.toString()
        val password = passwordField!!.text.toString()
        val passwordOk = password.equals(PASSWORD)
        val usernameOk = username.equals(USERNAME)

        if (passwordOk && usernameOk) {

            val intent = Intent(this, listViewdata::class.java)
            intent.putExtra(USERNAME, username)
            startActivity(intent)
        } else {
            usernameField!!.error = "Try again"
        }
    }

    companion object {

        val PREF_FILE_NAME = "login"
        val USERNAME = "Rebecca"
        val PASSWORD = "123"
    }

}
