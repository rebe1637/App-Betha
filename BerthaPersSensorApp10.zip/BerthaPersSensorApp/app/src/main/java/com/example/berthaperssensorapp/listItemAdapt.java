package com.example.berthaperssensorapp;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

public class listItemAdapt extends ArrayAdapter<listData> {
    private final int resource;

    public listItemAdapt(Context context, int resource, List<listData> objects) {
        super(context, resource, objects);
        this.resource = resource;
    }

    public listItemAdapt(Context context, int resource, listData[] objects) {
        super(context, resource, objects);
        this.resource = resource;
    }

    @NonNull
    @Override

    public View getView(int positon, View convertView, @NonNull ViewGroup parent) {
        listData data=getItem(positon);
        int deviceId=data.getDeviceId();
        String userId=data.getUserId();

        double pm25=data.getPm25();


        LinearLayout dataView;
        if (convertView==null){
            dataView=new LinearLayout(getContext());
            String inflater=Context.LAYOUT_INFLATER_SERVICE;
            LayoutInflater li=(LayoutInflater)getContext().getSystemService(inflater);
            li.inflate(resource,dataView,true);
        }
        else {
            dataView=(LinearLayout)convertView;
        }
        TextView userView=dataView.findViewById(R.id.datalist_item_userId);
        TextView deviceIdView=dataView.findViewById(R.id.datalist_item_deviceId);
        userView.setText("  By  "+userId);
        deviceIdView.setText("Device id:  "+String.valueOf(deviceId)+".");
        return dataView;

    }


}
