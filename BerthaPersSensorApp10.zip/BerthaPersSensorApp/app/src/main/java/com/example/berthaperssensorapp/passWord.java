package com.example.berthaperssensorapp;

public class passWord {
    public static boolean Check(String username, String password) {
        return password.startsWith("123");
    }
}
